#需要安装pip install python-multipart
from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import StreamingResponse
from PIL import  Image
import uuid
import json
import time
import random
import os.path as path


#可调设置
TIMEOUT_R=300.  #refresh_token失效时间
TIMEOUT_A=120.  #access_token失效时间
DELAY=True      #是否模拟网络延迟


app = FastAPI()
# 设置跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有域名
    allow_credentials=True,
    allow_methods=["*"],  # 允许所有方法
    allow_headers=["*"],  # 允许所有头部
)
# 静态资源目录
app.mount("/pic", StaticFiles(directory="uploads/pictures"), name="pic")
# 自定义异常
class UnicornException(Exception):
    def __init__(self, status_code:int, data:dict):
        self.status_code = status_code
        self.data = data
@app.exception_handler(UnicornException)
async def unicorn_exception_handler(request: Request, exc: UnicornException):
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.data
    )

users={}
rts={}
ats={}
all_qs={}

def genRand(at):
    val=str(uuid.uuid4())
    while val in at: val=str(uuid.uuid4())
    return val
def checkAuth(auth):
    auth=str(auth)
    if not auth.startswith("Bearer "):
        raise UnicornException(401, {"code":401,"message":"无效的token!"})
    access_token= auth[7:]
    if access_token not in ats or time.time()-ats[access_token]["time"]>TIMEOUT_A:
        raise UnicornException(401, {"code":401,"message":"无效的token!"})
    return access_token
def delay():
    if DELAY==True:
        time.sleep(random.randrange(1,10)/4)
@app.post("/api/register")
async def reg(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if name in users:
        raise UnicornException(409,{"code":409,"message":"用户名已经存在！"})
    # 定义用户 define user
    users[name]={"username":name,"password":reginfo["password"],"sessions":{},"name":"<%s>"%name,"photo":"./pic/DefaultPhoto.png"}
    return {"code":201,"message":"注册成功！"}

@app.post("/api/login")
async def login(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if (name not in users)or(reginfo["password"]!=users[name]["password"]):
        raise UnicornException(400,{"code":400,"message":"用户名或密码错误！"})
    access_token=genRand(ats)
    refresh_token=genRand(rts)
    rts[refresh_token]={"at":access_token,"time":time.time()}
    ats[access_token]={"user":users[name],"time":time.time()}
    return {"code":200,"message": "登录成功!","data":{"access_token":access_token,"refresh_token":refresh_token}}

@app.post("/api/refresh")
async def refresh(request:Request):
    reginfo= await request.json()
    refresh_token=reginfo["refresh_token"]
    if refresh_token in rts:
        rt=rts[refresh_token]
        if time.time()-rt["time"]<=TIMEOUT_R:
            user=ats[rt["at"]]["user"]
            del ats[rt["at"]]
            access_token=genRand(ats)
            ats[access_token]={"user":user,"time":time.time()}
            rt["at"]=access_token
            return {"code":200,"message": "access_token刷新成功!","data":{"access_token":access_token,"token_type": "bearer"}}
        else:
            del rts[refresh_token]
    raise UnicornException(401, {"code":401,"message":"refresh token无效!"})

def fake_chat_streamer(q:str,session):
    qid=genRand(all_qs)
    o={"choices":[{"message":{"role":"assistant","content":""}}],"final":False,"id":qid,"created": int(time.time()*1000)}
    with open("text.txt","r",encoding="utf8") as f: data = f.read()
    allText=''
    for i in range(len(q)):
        if i%4==3: time.sleep(1)
        o["choices"][0]["message"]["content"]=data
        allText+=data
        yield json.dumps(o)
    # 总内容
    o["choices"][0]["message"]["content"]=allText
    o["final"]=True
    obj_q={"question_id":qid,"question":q,"answer":allText,"timestamp":int(time.time()*1000)}
    all_qs[qid]=obj_q
    session["qs"][qid]=obj_q
    yield json.dumps(o)
@app.post("/v1/chat/completions")
async def read_chat(request:Request):
    delay()
    access_token= checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    session=user["sessions"].get(request_body["session_id"])
    if session is None:
        raise UnicornException(400, {"code":400,"message":"无效的会话ID"})
    #问题
    question=request_body["messages"][0]["content"]
    rsp=StreamingResponse(fake_chat_streamer(question,session),media_type="application/json")
    # rsp.headers["X-Accel-Buffering"]="no"
    return rsp

@app.post("/v1/related_questions")
async def related_questions(request:Request):
    checkAuth(request.headers["Authorization"])
    #请求内容
    request_body=await request.json()
    #问题
    question=request_body["question"]
    related_questions=[
        "[%s]相关问题1"%question,
        "[%s]相关问题2"%question
    ]
    if len(question)>5: related_questions.append("[%s]相关问题3"%question)
    return {"message": "成功找到相关问题","status": "success","related_questions":related_questions}

@app.get("/v1/reference_files")
async def reference_files(request:Request):
    checkAuth(request.headers["Authorization"])
    #问题id
    question_id=request.query_params["question_id"]
    if question_id not in all_qs:raise UnicornException(404, {"code":404,"message":"未找到指定的 question_id 或相关文档。"})
    reference_files=[
        {
        "type": "internal",
        "name": "[%s]内部文档.pdf"%(question_id),
        "url": "https://your-oss-bucket-name.oss.your-region.aliyuncs.com/documents/12345.pdf"
        },
        {
        "type": "external",
        "name": "CSDN相关文章",
        "url": "https://blog.csdn.net/article-12345"
        }
    ]
    return {"message": "成功获取相关文档","status": "success","reference_files":reference_files}

@app.post("/add_session")
async def add_session(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    #问题
    name=request_body["name"]
    session_id=request_body["session_id"]
    if not name or not session_id: raise UnicornException(400,{"code":400,"message":"无效参数"})
    user["sessions"][session_id]={"session_id":session_id,"name":name,"timestamp":int(time.time()*1000),"qs":{}}
    return {"code": 201,"message": "添加会话成功!","data": None}

@app.put("/rename_session")
async def rename_session(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    sessions=user["sessions"]

    #请求内容
    request_body=await request.json()

    sid=request_body["session_id"]
    newname=request_body["name"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    if not newname:
        raise UnicornException(400, {"code":400,"message":"名称为空"})
    sessions[sid]["name"]=newname
    return {"code": 200,"message": "重命名成功!","data": None}

@app.delete('/delete_session/{sid}')
async def delete_session(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    sid=request.path_params["sid"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    del sessions[sid]
    return {"code": 200,"message": "删除会话成功!","data": None}

@app.delete('/delete_all_sessions')
async def delete__all_session(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    sessions.clear()
    return {"code": 200,"message": "删除所有会话成功!","data": None}

@app.get('/get_sessions')
async def get_sessions(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    data=[]
    for s in sessions.values():
        s=s.copy()
        del s["qs"]
        data.append(s)
    return {"code": 200,"message": "获取会话列表成功！","data": data}

@app.delete('/delete_qa')
async def delete_qa(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]

    request_body=await request.json()
    sid=request_body["session_id"]
    qid=request_body["question_id"]
    if sid not in sessions or qid not in all_qs:
        raise UnicornException(400, {"code":400,"message":"无效的会话或问题 ID"})
    del all_qs[qid]
    del sessions[sid]["qs"][qid]
    return {"code": 200,"message": "删除历史对话成功!","data":None}

@app.get('/get_qas')
async def get_qas(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    
    sid=request.query_params["session_id"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"会话不存在"})
    data=list(sessions[sid]["qs"].values())
    return {"code": 200,"message": "获取历史对话列表成功!","data": data}

@app.get('/get_info')
async def get_info(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    data={"username":user["username"],"name":user["name"],"photo":user["photo"],}
    return {"code": 200,"message": "查询成功!","data": data}

@app.post('/upload_image')
async def upload_image(request:Request):
    checkAuth(request.headers["Authorization"])
    #请求内容
    request_from=await request.form()
    _,ext=path.splitext(request_from["photo"].filename)
    photo=await request_from["photo"].read()

    filename=str(uuid.uuid4())+(ext if ext else '')
    with open("./uploads/pictures/"+filename,"wb") as f: f.write(photo)
    url=request.url
    return {"code": 201,"message": "上传成功!","data": "%s://%s/pic/%s"%(url.scheme,url.netloc,filename)}

@app.put('/update_info')
async def update_info(request:Request):
    access_token=checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_json=await request.json()
    if request_json.get("name"): user["name"]=request_json["name"]
    if request_json.get("photo"): user["photo"]=request_json["photo"]
    
    return {"code": 200,"message": "更新成功!","data": []}

@app.put('/change_password')
async def update_info(request:Request):
    access_token=checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_json=await request.json()
    newpswd=request_json.get("password")
    if not newpswd or newpswd==user["password"]:
         raise UnicornException(400, {"code":400,"message":"密码不能为空或与原密码相同","data":[]})
    user["password"]=newpswd
    return {"code": 200,"message": "更新成功!","data": []}

@app.delete('/cancel_account')
async def cancel_account(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    del users[user["username"]]
    return {"code": 200,"message": "注销成功!","data": None}

#返回所有信息
@app.get('/test')
async def test():
    return users


# 这个是直接在这里启动uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("uvi_server:app", host="0.0.0.0", port=8000, reload=True)