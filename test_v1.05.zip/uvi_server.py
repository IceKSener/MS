#需要安装fastapi、uvicorn和python-multipart
try:
    import python_multipart
    import fastapi
    import uvicorn
except Exception as e:
    print("该脚本需要安装fastapi、uvicorn和python-multipart库")
    print("请pip install fastapi uvicorn python-multipart")
    input()
    exit(0)
from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import StreamingResponse
import uuid
import json
import time
import random
import os.path as path


#可调设置
TIMEOUT_R=300.  #refresh_token失效时间
TIMEOUT_A=120.  #access_token失效时间
DELAY=True      #是否模拟网络延迟

SERVER_VERSION="v1.03"

app = FastAPI()
# 设置跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有域名
    allow_credentials=True,
    allow_methods=["*"],  # 允许所有方法
    allow_headers=["*"],  # 允许所有头部
)
# 静态资源目录
app.mount("/pic", StaticFiles(directory="uploads/pictures"), name="pic")
# 自定义异常
class UnicornException(Exception):
    def __init__(self, status_code:int, data:dict):
        self.status_code = status_code
        self.data = data
@app.exception_handler(UnicornException)
async def unicorn_exception_handler(request: Request, exc: UnicornException):
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.data
    )

users={}
rts={}
ats={}
all_qs={}

def genRand(at):
    val=str(uuid.uuid4())
    while val in at: val=str(uuid.uuid4())
    return val
def checkAuth(auth):
    auth=str(auth)
    if not auth.startswith("Bearer "):
        raise UnicornException(401, {"code":401,"message":"无效的token!"})
    access_token= auth[7:]
    if access_token not in ats or time.time()-ats[access_token]["time"]>TIMEOUT_A:
        raise UnicornException(401, {"code":401,"message":"过期的token!"})
    return access_token
def delay():
    if DELAY==True:
        time.sleep(random.randrange(1,10)/4)
@app.post("/api/register",status_code=201)
async def reg(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if name in users:
        raise UnicornException(409,{"code":409,"message":"用户名已经存在！"})
    # 定义用户 define user
    users[name]={"username":name,"password":reginfo["password"],"sessions":{},"name":"<%s>"%name,"photo":"./pic/DefaultPhoto.png"}
    return {"code":201,"message":"注册成功！","data":{"username":name,"id":len(users)}}

@app.post("/api/login")
async def login(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if name not in users:
        raise UnicornException(400,{"code":400,"message":"用户名不存在!"})
    if reginfo["password"]!=users[name]["password"]:
        raise UnicornException(400,{"code":400,"message":"密码错误!"})
    access_token=genRand(ats)
    refresh_token=genRand(rts)
    rts[refresh_token]={"at":access_token,"time":time.time()}
    ats[access_token]={"user":users[name],"time":time.time()}
    return {"code":200,"message": "登录成功!","data":{"access_token":access_token,"token_type": "bearer","refresh_token":refresh_token}}

@app.post("/api/refresh")
async def refresh(request:Request):
    reginfo= await request.json()
    refresh_token=reginfo["refresh_token"]
    if refresh_token in rts:
        rt=rts[refresh_token]
        if time.time()-rt["time"]<=TIMEOUT_R:
            user=ats[rt["at"]]["user"]
            del ats[rt["at"]]
            access_token=genRand(ats)
            ats[access_token]={"user":user,"time":time.time()}
            rt["at"]=access_token
            return {"code":200,"message": "access_token刷新成功!","data":{"access_token":access_token,"token_type": "bearer"}}
        else:
            del rts[refresh_token]
    raise UnicornException(401, {"code":401,"message":"refresh token无效!"})

def fake_chat_streamer(q:str,session):
    qid=genRand(all_qs)
    # 定义qa define qa
    obj_q={"question_id":qid,"question":q,"answer":'',"timestamp":time.time()}
    all_qs[qid]=obj_q
    session["qs"][qid]=obj_q
    session["latest_qid"]=qid
    message={"role":"assistant","content":""}
    usage={"total_tokens": len(q),"prompt_tokens": len(q),"completion_tokens": 0}
    o={
        "id":qid,
        "object": "text_completion",
        "created": time.time(),
        "model": "TestServer-%s"%SERVER_VERSION,
        "choices":[{"message":message,"finish_reason":"length"}],
        "usage":usage,
        "final":False,
    }
    with open("text.txt","r",encoding="utf8") as f: data = f.read()
    allText=''
    for i in range(len(q)):
        if i%4==3: time.sleep(1)
        message["content"]=data
        usage["total_tokens"]+=len(data)
        usage["completion_tokens"]+=len(data)
        allText+=data
        print("返回:"+data)
        yield json.dumps(o)
    # 总内容
    o["choices"][0]["finish_reason"]="stop"
    o["final"]=True
    message["content"]=allText
    obj_q["answer"]=allText
    if obj_q.get("num_render") is None: obj_q["num_render"]=len(allText)
    print("回答结束，num_render:",obj_q["num_render"])
    yield json.dumps(o)
@app.post("/v1/chat/completions")
async def read_chat(request:Request):
    delay()
    access_token= checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    session=user["sessions"].get(request_body["session_id"])
    if session is None:
        raise UnicornException(400, {"code":400,"message":"无效的会话ID"})
    #问题
    question=request_body["messages"][0]["content"]
    rsp=StreamingResponse(fake_chat_streamer(question,session),media_type="application/json")
    # rsp.headers["X-Accel-Buffering"]="no"
    return rsp

@app.post("/v1/related_questions")
async def related_questions(request:Request):
    checkAuth(request.headers.get("Authorization"))
    #请求内容
    request_body=await request.json()
    #问题
    question=request_body.get("question")
    if question is None:
        raise UnicornException(400, {"code":400,"message":"请求体中缺少 'question' 字段!"})
    related_questions=[
        "[%s]相关问题1"%question,
        "[%s]相关问题2"%question
    ]
    if len(question)>5: related_questions.append("[%s]相关问题3"%question)
    return {"message": "成功找到相关问题","status": "success","related_questions":related_questions}

@app.get("/v1/reference_files")
async def reference_files(request:Request):
    checkAuth(request.headers.get("Authorization"))
    #问题id
    question_id=request.query_params["question_id"]
    if question_id not in all_qs:raise UnicornException(404, {"code":404,"message":"未找到指定的 question_id 或相关文档。"})
    reference_files=[
        {
        "type": "internal",
        "name": "[%s]内部文档.pdf"%(question_id),
        "url": "https://your-oss-bucket-name.oss.your-region.aliyuncs.com/documents/12345.pdf"
        },
        {
        "type": "external",
        "name": "CSDN相关文章",
        "url": "https://blog.csdn.net/article-12345"
        }
    ]
    return {"message": "成功获取相关文档","status": "success","reference_files":reference_files}

@app.post("/add_session",status_code=201)
async def add_session(request:Request):
    delay()
    access_token = checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    #问题
    name=request_body["name"]
    session_id=request_body["session_id"]
    if not name or not session_id: raise UnicornException(400,{"code":400,"message":"无效参数"})
    user["sessions"][session_id]={"session_id":session_id,"name":name,"timestamp":time.time(),"qs":{}}
    return {"code": 201,"message": "添加会话成功!","data": None}

@app.put("/rename_session")
async def rename_session(request:Request):
    delay()
    access_token = checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    sessions=user["sessions"]

    #请求内容
    request_body=await request.json()

    sid=request_body["session_id"]
    newname=request_body["name"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    if not newname:
        raise UnicornException(400, {"code":400,"message":"名称为空"})
    sessions[sid]["name"]=newname
    return {"code": 200,"message": "重命名成功!","data": None}

@app.delete('/delete_session/{sid}')
async def delete_session(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]
    sid=request.path_params["sid"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    for qid in sessions[sid]["qs"]:
        del all_qs[qid]
    del sessions[sid]
    return {"code": 200,"message": "删除会话成功!","data": None}

@app.delete('/delete_all_sessions')
async def delete_all_session(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]
    for sid in sessions:
        for qid in sessions[sid]["qs"]:
            del all_qs[qid]
    sessions.clear()
    return {"code": 200,"message": "删除所有会话成功!","data": None}

@app.get('/get_sessions')
async def get_sessions(request:Request):
    delay()
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]
    data=[]
    for s in sessions.values():
        s=s.copy()
        del s["qs"]
        data.append(s)
    return {"code": 200,"message": "获取会话列表成功！","data": data}

@app.delete('/delete_qa')
async def delete_qa(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]

    request_body=await request.json()
    sid=request_body["session_id"]
    qid=request_body["question_id"]
    if sid not in sessions or qid not in all_qs:
        raise UnicornException(400, {"code":400,"message":"无效的会话或问题 ID"})
    del all_qs[qid]
    del sessions[sid]["qs"][qid]
    return {"code": 200,"message": "删除历史对话成功!","data":None}

@app.get('/get_qas')
async def get_qas(request:Request):
    delay()
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]
    
    sid=request.query_params["session_id"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"会话不存在"})
    data=list(sessions[sid]["qs"].values())
    return {"code": 200,"message": "获取历史对话列表成功!","data": data}

@app.get('/get_info')
async def get_info(request:Request):
    delay()
    access_token = checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    data={"username":user["username"],"name":user["name"],"photo":user["photo"],}
    return {"code": 200,"message": "查询成功!","data": data}

@app.post('/upload_image',status_code=201)
async def upload_image(request:Request):
    checkAuth(request.headers.get("Authorization"))
    #请求内容
    request_from=await request.form()
    _,ext=path.splitext(request_from["photo"].filename)
    photo=await request_from["photo"].read()

    filename=str(uuid.uuid4())+(ext if ext else '')
    with open("./uploads/pictures/"+filename,"wb") as f: f.write(photo)
    url=request.url
    return {"code": 201,"message": "上传成功!","data": "%s://%s/pic/%s"%(url.scheme,url.netloc,filename)}

@app.put('/update_info')
async def update_info(request:Request):
    access_token=checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    #请求内容
    request_json=await request.json()
    if request_json.get("name"): user["name"]=request_json["name"]
    if request_json.get("photo"): user["photo"]=request_json["photo"]
    
    return {"code": 200,"message": "更新成功!","data": []}

@app.put('/change_password')
async def update_info(request:Request):
    access_token=checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    #请求内容
    request_json=await request.json()
    newpswd=request_json.get("password")
    if not newpswd or newpswd==user["password"]:
         raise UnicornException(400, {"code":400,"message":"密码不能为空或与原密码相同","data":[]})
    user["password"]=newpswd
    return {"code": 200,"message": "更新成功!","data": []}

@app.delete('/cancel_account')
async def cancel_account(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    user=ats[access_token]["user"]
    sessions=user["sessions"]
    for sid in sessions:
        for qid in sessions[sid]["qs"]:
            del all_qs[qid]
    del users[user["username"]]
    return {"code": 200,"message": "注销成功!","data": None}

@app.post('/stop_qa')
async def stop_qa(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]

    request_json=await request.json()
    sid=request_json.get("session_id")
    num_render=request_json.get("num_render")
    if sid not in sessions:
        raise UnicornException(404, {"code":404,"message":"会话不存在","data":None})
    last_qid=sessions[sid]["latest_qid"]
    all_qs[last_qid]["num_render"]=num_render
    return {"code": 200,"message": "中断生成成功!","data": None}

@app.put('/update_qa')
async def update_qa(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]

    request_json=await request.json()
    sid=request_json.get("session_id")
    qid=request_json.get("question_id")
    num_render=request_json.get("num_render")
    if sid not in sessions or qid not in sessions[sid]["qs"]:
        raise UnicornException(400, {"code":400,"message":"无效的会话或问题 ID","data":None})
    all_qs[qid]["num_render"]=num_render
    return {"code": 200,"message": "更新历史对话成功!","data": None}

@app.get('/get_qa')
async def get_qa(request:Request):
    access_token = checkAuth(request.headers.get("Authorization"))
    sessions=ats[access_token]["user"]["sessions"]

    sid=request.query_params.get("session_id")
    qid=request.query_params.get("question_id")
    
    if sid not in sessions or qid not in sessions[sid]["qs"]:
        raise UnicornException(400, {"code":400,"message":"会话或问答记录不存在","data":None})

    return {"code": 200,"message": "获取历史对话成功!","data": all_qs[qid]}

@app.post('/multipart/upload_audio',status_code=200)
async def upload_audio(request:Request):
    checkAuth(request.headers.get("Authorization"))
    #请求内容
    request_from=await request.form()
    audio=await request_from["file"].read()

    data="[未识别到语音]"
    if len(audio)>0:
        data="[识别到语音，但是我只是给简单的测试服务器，不知道你说了什么]"
    return {"code": 200,"message": "上传成功!","data": data}

@app.post('/multipart/upload_image',status_code=200)
async def upload_image(request:Request):
    checkAuth(request.headers.get("Authorization"))
    #请求内容
    request_from=await request.form()
    img=await request_from["file"].read()

    data="[未识别到图片]"
    if len(img)>0:
        data="[识别到图片，但是我真不知道里面有什么]"
    return {"code": 200,"message": "上传成功!","data": data}

#返回所有信息
@app.get('/test')
async def test():
    return users

#保存当前信息
@app.get('/save')
async def save():
    try:
        with open("save.json",'w',encoding='utf8') as f:
            f.write(json.dumps(users))
    except Exception as e:
        return {"error":str(e)}
    return {"message":"数据保存成功，已保存在save.json文件中"}

#加载信息
@app.get('/load')
async def load():
    try:
        with open("save.json",'r',encoding='utf8') as f:
            obj_u=json.loads(f.read())
            obj_q={}
            for user in obj_u.values():
                for session in user["sessions"].values():
                    for qid in session["qs"]:
                        obj_q[qid]=session["qs"][qid]
            global users
            global all_qs
            users=obj_u
            all_qs=obj_q
    except Exception as e:
        return {"error":str(e)}
    return {"message":"载入成功访问 /test 查看所有数据"}
load()

# 这个是直接在这里启动uvicorn
if __name__ == "__main__":
    print("输入http://localhost:8000/test 查看所有数据")
    print("输入http://localhost:8000/save 保存所有数据")
    print("输入http://localhost:8000/load 读取保存的数据")
    uvicorn.run("uvi_server:app", host="0.0.0.0", port=8000, reload=True)