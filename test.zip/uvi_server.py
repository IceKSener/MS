from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.responses import StreamingResponse
import json
import time
import random

#可调设置
TIMEOUT_R=300.  #refresh_token失效时间
TIMEOUT_A=120.  #access_token失效时间
DELAY=True      #是否模拟网络延迟


app = FastAPI()
# 设置跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 允许所有域名
    allow_credentials=True,
    allow_methods=["*"],  # 允许所有方法
    allow_headers=["*"],  # 允许所有头部
)
# 自定义异常
class UnicornException(Exception):
    def __init__(self, status_code:int, data:dict):
        self.status_code = status_code
        self.data = data
@app.exception_handler(UnicornException)
async def unicorn_exception_handler(request: Request, exc: UnicornException):
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.data
    )

users={}
rts={}
ats={}
all_qs={}

def genRand(at):
    val=str(random.randint(0,100000000))
    while val in at: val=str(random.randint(0,100000000))
    return val
def checkAuth(auth):
    auth=str(auth)
    if not auth.startswith("Bearer "):
        raise UnicornException(401, {"code":401,"message":"无效的token!"})
    access_token= auth[7:]
    if access_token not in ats or time.time()-ats[access_token]["time"]>TIMEOUT_A:
        raise UnicornException(401, {"code":401,"message":"无效的token!"})
    return access_token
def delay():
    if DELAY==True:
        time.sleep(random.randrange(1,10)/4)
@app.post("/api/register")
async def reg(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if name in users:
        raise UnicornException(409,{"code":409,"message":"用户名已经存在！"})
    users[name]={"username":name,"password":reginfo["password"],"sessions":{}}
    return {"code":201,"message":"注册成功！"}

@app.post("/api/login")
async def login(request:Request):
    reginfo= await request.json()
    name=reginfo["username"]
    if (name not in users)or(reginfo["password"]!=users[name]["password"]):
        raise UnicornException(400,{"code":400,"message":"用户名或密码错误！"})
    access_token=genRand(ats)
    refresh_token=genRand(rts)
    rts[refresh_token]={"at":access_token,"time":time.time()}
    ats[access_token]={"user":users[name],"time":time.time()}
    return {"code":200,"message": "登录成功!","data":{"access_token":access_token,"refresh_token":refresh_token}}

@app.post("/api/refresh")
async def refresh(request:Request):
    reginfo= await request.json()
    refresh_token=reginfo["refresh_token"]
    if refresh_token in rts:
        rt=rts[refresh_token]
        if time.time()-rt["time"]<=TIMEOUT_R:
            user=ats[rt["at"]]["user"]
            del ats[rt["at"]]
            access_token=genRand(ats)
            ats[access_token]={"user":user,"time":time.time()}
            rt["at"]=access_token
            return {"code":200,"message": "access_token刷新成功!","data":{"access_token":access_token,"token_type": "bearer"}}
        else:
            del rts[refresh_token]
    raise UnicornException(401, {"code":401,"message":"refresh token无效!"})

def fake_chat_streamer(q:str,session):
    qid=genRand(all_qs)
    o={"choices":[{"message":{"role":"assistant","content":""}}],"final":False,"id":qid,"created": int(time.time()*1000)}
    with open("text.txt","r",encoding="utf8") as f: data = f.read()
    allText=''
    for i in range(len(q)):
        if i%4==3: time.sleep(1)
        o["choices"][0]["message"]["content"]=data
        allText+=data
        yield json.dumps(o)
    # 总内容
    o["choices"][0]["message"]["content"]=allText
    o["final"]=True
    obj_q={"question_id":qid,"question":q,"answer":allText,"timestamp":int(time.time()*1000)}
    all_qs[qid]=obj_q
    session["qs"][qid]=obj_q
    yield json.dumps(o)
@app.post("/v1/chat/completions")
async def read_chat(request:Request):
    delay()
    access_token= checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    session=user["sessions"].get(request_body["session_id"])
    if session is None:
        raise UnicornException(400, {"code":400,"message":"无效的会话ID"})
    #问题
    question=request_body["messages"][0]["content"]
    rsp=StreamingResponse(fake_chat_streamer(question,session),media_type="application/json")
    # rsp.headers["X-Accel-Buffering"]="no"
    return rsp

@app.post("/v1/related_questions")
async def related_questions(request:Request):
    checkAuth(request.headers["Authorization"])
    #请求内容
    request_body=await request.json()
    #问题
    question=request_body["question"]
    related_questions=[
        "[%s]相关问题1"%question,
        "[%s]相关问题2"%question
    ]
    if len(question)>5: related_questions.append("[%s]相关问题3"%question)
    return {"message": "成功找到相关问题","status": "success","related_questions":related_questions}

@app.get("/v1/reference_files")
async def reference_files(request:Request):
    checkAuth(request.headers["Authorization"])
    #问题id
    question_id=request.query_params["question_id"]
    if question_id not in all_qs:raise UnicornException(404, {"code":404,"message":"未找到指定的 question_id 或相关文档。"})
    reference_files=[
        {
        "type": "internal",
        "name": "[%s]内部文档.pdf"%(question_id),
        "url": "https://your-oss-bucket-name.oss.your-region.aliyuncs.com/documents/12345.pdf"
        },
        {
        "type": "external",
        "name": "CSDN相关文章",
        "url": "https://blog.csdn.net/article-12345"
        }
    ]
    return {"message": "成功获取相关文档","status": "success","reference_files":reference_files}

@app.post("/add_session")
async def add_session(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    #请求内容
    request_body=await request.json()
    #问题
    name=request_body["name"]
    session_id=request_body["session_id"]
    if not name or not session_id: raise UnicornException(400,{"code":400,"message":"无效参数"})
    user["sessions"][session_id]={"session_id":session_id,"name":name,"timestamp":int(time.time()*1000),"qs":{}}
    return {"code": 201,"message": "添加会话成功!","data": None}

@app.put("/rename_session")
async def rename_session(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    user=ats[access_token]["user"]
    sessions=user["sessions"]

    #请求内容
    request_body=await request.json()

    sid=request_body["session_id"]
    newname=request_body["name"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    if not newname:
        raise UnicornException(400, {"code":400,"message":"名称为空"})
    sessions[sid]["name"]=newname
    return {"code": 200,"message": "重命名成功!","data": None}

@app.delete('/delete_session/{sid}')
async def delete_session(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    sid=request.path_params["sid"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"无效的会话 ID"})
    del sessions[sid]
    return {"code": 200,"message": "删除会话成功!","data": None}

@app.delete('/delete_all_sessions')
async def delete__all_session(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    sessions.clear()
    return {"code": 200,"message": "删除所有会话成功!","data": None}

@app.get('/get_sessions')
async def get_sessions(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    data=[]
    for s in sessions.values():
        s=s.copy()
        del s["qs"]
        data.append(s)
    return {"code": 200,"message": "获取会话列表成功！","data": data}

@app.delete('/delete_qa')
async def delete_qa(request:Request):
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]

    request_body=await request.json()
    sid=request_body["session_id"]
    qid=request_body["question_id"]
    if sid not in sessions or qid not in all_qs:
        raise UnicornException(400, {"code":400,"message":"无效的会话或问题 ID"})
    del all_qs[qid]
    del sessions[sid]["qs"][qid]
    return {"code": 200,"message": "删除历史对话成功!","data":None}

@app.get('/get_qas')
async def get_qas(request:Request):
    delay()
    access_token = checkAuth(request.headers["Authorization"])
    sessions=ats[access_token]["user"]["sessions"]
    
    sid=request.query_params["session_id"]
    if sid not in sessions:
        raise UnicornException(400, {"code":400,"message":"会话不存在"})
    data=list(sessions[sid]["qs"].values())
    return {"code": 200,"message": "获取历史对话列表成功!","data": data}

#返回所有信息
@app.get('/test')
async def test():
    return users


# 这个是直接在这里启动uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("uvi_server:app", host="0.0.0.0", port=8000, reload=True)